Epoch AI, 'AI Benchmarking Hub'. CC BY 4.0.
